
package registrationapp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

/**
 *
 * @author THULANI MGIDI
 */
public class LoginTest {

    private Login login;

    public LoginTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
         login= new Login();
    }

    @After
    public void tearDown() {
    }
    
     //Test of checkUserName method, of class Login.
     
    @Test
    public void testCheckUserName() {
        assertEquals("Valid username should return true", login.checkUserName("kyl_1"));
        assertEquals("Invalid username should return false", login.checkUserName("kyle!!!!!!!"));
    }

    
     //Test of checkPasswordComplexity method, of class Login.
     
    @Test
    public void testCheckPasswordComplexity() {
        assertEquals("Valid password should return true", login.checkPasswordComplexity("Ch&&sec@ke99!"));
        assertEquals("Invalid password should return false", login.checkPasswordComplexity("password"));
    }

    
     // Test of checkCellPhoneNumber method, of class Login.
     
    @Test
    public void testCheckCellPhoneNumber() {
        assertEquals("Valid phone should return true", login.checkCellPhoneNumber("+27838968976"));
        assertEquals("Invalid phone should return false", login.checkCellPhoneNumber("08966553"));
    }

    
     // Test of registerUser method, of class Login.
     
    @Test
    public void testRegisterUser() {
        // Successful registration
        boolean success = login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertTrue("Registration successful.", success);

        // Invalid username
        boolean invalidUser = login.registerUser("kyle!!!!!!!", "Ch&&sec@ke99!", "+27838968976");
        assertFalse("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.", invalidUser);

        // Invalid password
        boolean invalidPass = login.registerUser("kyl_1", "password", "+27838968976");
        assertFalse("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.", invalidPass);

        // Invalid cell number
        boolean invalidCell = login.registerUser("kyl_1", "Ch&&sec@ke99!", "08966553");
        assertFalse("Cell phone number incorrectly formatted or does not contain international code.", invalidCell);
    }

     // Test of loginUser method, of class Login.
     
    
    @Test
    public void testLoginUser() {
        
        //Register a valid user first
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        
        //Correct credentials
        assertTrue("Correct credentials should return true", login.loginUser("kyl_1", "Ch&&sec@ke99!"));
        
        //Incorrect credentials
        assertFalse("Incorrect credentials should return false", login.loginUser("wrong", "wrongpass"));
    }

     // Test of returnLoginStatus method, of class Login.
     
    @Test
    public void testReturnLoginStatus() {
        
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");

        String success = login.returnLoginStatus("kyl_1", "Ch&&sec@ke99!", true);
        assertEquals("Welcome Kyle Smith it is great to see you again.", success);

        String fail = login.returnLoginStatus("wrong", "wrongpass", false);
        assertEquals("Username or password incorrect, please try again.", fail);
    }

}